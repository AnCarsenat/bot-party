FIx : pressing action in campaign adds players
Fix : bots should be setup in player tab.
Fix : let place stuff even outside place mode with place instead of give.
Fix : make console a bit smaller
Feature : add party settings (win score, round duration, even chances etc)
Maps : maybe load from tscn instead of a new format ? and it needs to be able to add objects like the party obstacles etc.
Feature : be able to change your port for hosting.
Feature : hosting from commandline
Feature : save states in commandline
Fix : bumper doesn't look right during placement
Fix : the map editor window should be nicer.
Feature : add a simple gamemode mod that adds a new gamemode
Feature : add an ingame editor for node properties etc (~ then editor)
Fix : mines and items are invisible during placement if used 
Fix : plane launcher should be a travel method not a offensive thing
Fix : wind direction is wrong 
Fix : if someone is far away and the option show distant players is enabled, a bubble with an arrow pointing towards that player contains a samll splitscreen of that player's pov.
Fix : next command in party mode should skip to next round

